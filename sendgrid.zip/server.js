const express = require('express');
var cron = require('node-cron');

const app = express();

const sgMail = require('@sendgrid/mail');
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

const msg = {
  to: 'zechnwhite@gmail.com',
  from: 'zechnwhite@gmail.com',
  subject: 'happy birthday! :)',
  text: 'and easy to do anywhere, even with Node.js',
  html: '<h2>Yee Haw!</h2><p><strong>Lick my love pump.</strong></p>'
};

// cron.schedule('* * * * *', () => {
//     console.log('running a task every minute');
//     sgMail.send(msg);
// });

app.use(express.static('public'));

app.get('/sendemail', (req, res) => {
  const thisMsg = {
    to: 'zechnwhite@gmail.com',
    from: 'zechnwhite@gmail.com',
    subject: 'happy birthday! :)',
    text: 'and easy to do anywhere, even with Node.js',
    html: '<h2>Yee Haw!</h2><p><strong>Lick my love pump.</strong></p>'
  };
  sgMail.send(thisMsg);
});

app.listen(3000);
